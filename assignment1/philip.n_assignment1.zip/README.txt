Name:       Philip Nygard
Course:     Mat340
Section:    A
Semester:   Spring 2019

How to use:
Run the executable from either powershell or the command prompt and
follow the instructions on screen