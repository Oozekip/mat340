Philip Nygard
MAT340-a
Spring 2019

To run: 
    Open exe
    Chose experiment
    Follow directions

Note:
    For correlation experiment, a file called "Coding3_Data.xlsx" must be present
    in the same format as the one provided. Data is read directly from the spreadsheet,
    name is in the top row. 

    Starting in the second row:
        First column is midterm grades
        Second column is homework grades
        Third column is
